import generateWordCount from "./src";

const path = process.argv[2];

generateWordCount(path);
